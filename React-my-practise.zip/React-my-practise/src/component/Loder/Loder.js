import React from "react";

export const Loder = () => {
  return (
    <div className="custom-loader">
      <div className="ring"></div>
      <span>loading...</span>
    </div>
  );
};
