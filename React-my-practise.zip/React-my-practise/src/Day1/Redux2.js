import React from 'react'
import Redux3 from './Redux3'

function Redux2() {
  return (
    <div>
   <Redux3/>
    </div>
  )
}

export default Redux2
